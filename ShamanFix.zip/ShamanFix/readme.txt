In vanilla, the shaman class colour is the same as the paladin's: pink. In later expansions,
it was changed to the blue we all know and love. This addon fixes that. It does this by 
inserting the rgb code for the colour blue used in later expansions, into the RAID_CLASS_COLOR table.

Almost every other addon uses this table, so this means that this addon fixes all of those.

Haha no. Almost every UI addon has its own system and ignores the global color table. So this addon is full of hackfixes to force other addons to display Shamans as blue.
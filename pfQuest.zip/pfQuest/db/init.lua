pfDB = {
  ["units"] = {},
  ["objects"] = {},
  ["quests"] = {},
  ["items"] = {},
  ["zones"] = {},
  ["professions"] = {},
  ["meta"] = {},
}
  
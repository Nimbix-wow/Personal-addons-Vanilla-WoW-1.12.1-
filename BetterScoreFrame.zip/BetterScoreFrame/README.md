BetterScoreFrame - a World of Warcraft (1.12.1) AddOn
====================================

Installation:

Put "BetterScoreFrame" folder into ".../World of Warcraft/Interface/AddOns/".
Create AddOns folder if necessary

After Installation directory tree should look like the following

<pre>
World of Warcraft
`- Interface
   `- AddOns
      `- BetterScoreFrame
         |-- BetterScoreFrame.lua
         |-- BetterScoreFrame.toc
         |-- BetterScoreFrame.xml
         `-- README.md

</pre>

Features:
- Colors player names by class in battleground Score Frame.

Known Issues:
- None.
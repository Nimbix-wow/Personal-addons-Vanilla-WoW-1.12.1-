FuBar - HonorFu v1.1 $Revision: 12402 $

Author: ckknight (ckknight@gmail.com)
$Date: 2006-09-30 18:58:37 -0400 (Sat, 30 Sep 2006) $

German localization: neriak (webmaster@neriak.de)

Keeps track of honor and PvP statistics.

TO INSTALL: Put the FuBar_HonorFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures

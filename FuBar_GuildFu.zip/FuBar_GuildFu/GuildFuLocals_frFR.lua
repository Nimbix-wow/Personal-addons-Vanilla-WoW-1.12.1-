function GuildFu_Locals_frFR()
GuildFULocals = {
	NAME = "FuBar - GuildFu",
	DESCRIPTION = "Keeps track of your Guild members.",
	COMMANDS = {"/fbg", "/fbguild", "/fubar_guild"},
	CMD_OPTIONS = {},
	ARGUMENT_HIDELOCATION = "hideLocation",
	ARGUMENT_HIDELEVEL = "hideLevel",
	ARGUMENT_HIDECLASS = "hideClass",
	ARGUMENT_HIDELABEL = "hideLabel",
	ARGUMENT_SETLEADTEXT = "leadtext",
    ARGUMENT_SETLEVELRANGE = "levelrange",
	ARGUMENT_SETREFRESH = "refreshrate",
	MENU_DISPLAY = "Show",
	MENU_ORDER = "Order",
	MENU_SHOW_LOCATION = "Show location",
	MENU_SHOW_LEVEL = "Show level",
	MENU_SHOW_CLASS = "Show class",
	MENU_SHOW_RACE = "Show race",
	MENU_SHOW_RANK = "Show rank",
	MENU_SHOW_PUBLICNOTES = "Show public notes",
	MENU_SHOW_OFFICERNOTES = "Show officer notes",	
	MENU_SHOW_LABEL = "Show label",
	MENU_SHOW_TOTAL = "Montre totale",
	MENU_COLORNAMES = "Color playernames according to class",
	MENU_ORDER_LOCATION = "By location",
	MENU_ORDER_LEVEL = "By level",
	MENU_ORDER_CLASS = "By class",
	MENU_ORDER_NAME = "By name",	
	MENU_INVITE = "Invite",
	MENU_WHISPER = "Whisper",
	MENU_PAGING = "Use Paging",
	MENU_PAGING_PREV = "|cff00ff33Previous page ...|r",
	MENU_PAGING_NEXT = "|cff00ff33Next page ...|r",
	MENU_PAGING_PAGE = "|cffffcc00Page %i/%i|r",
	MENU_PAGING_WARNING = "|cffff0000Too many persons, use paging.|r",
	MAX_ITEMS_SHOW = 25,
    WowMaxLevel = 60, 
    REFRESHINTERVAL = 120, 
    MENU_FILTER_LEVELRANGE = 5, 
	MENU_FILTER = "Filter",
	MENU_FILTER_CLASS = "Class",
	MENU_FILTER_LEVEL = "Level",
	MENU_FILTER_ZONE = "Zone",
	MENU_FILTERS_ZONE= {
		"People in my zone",
		"People not in an instance",
		"People not in battlegrounds"
	},
	SYSMSG_ONLINE = "has come online",
	SYSMSG_OFFLINE = "has gone offline",
	SYSMSG_ADDED = "added to friends.",
	SYSMSG_REMOVED = "removed from friends list.",
	TOOLTIP_TITLE = "Guidlist",
	TOOLTIP_NOTINGUILD = "Not in guild",
	TOOLTIP_WARNING = "|cffff0000Too many persons, use filtering.|r",
	hordeClassValues = {"Tous", "Guerrier", "Mage", "Voleur", "Druide", "Chasseur", "Chaman", "Pr\195\170tre", "D\195\169moniste"},
	allianceClassValues = {"Tous", "Guerrier", "Mage", "Voleur", "Druide", "Chasseur", "Pr\195\170tre", "D\195\169moniste", "Paladin"},

	colorclasses = { 
		["Chasseur"] = "|cffaad372", 
		["D\195\169moniste"] = "|cff9382c9", 
		["Pr\195\170tre"] = "|cffffffff", 
		["Paladin"] = "|cfff48cba", 
		["Chaman"] = "|cfff48cba", 
		["Mage"] = "|cff68ccef", 
		["Voleur"] = "|cfffff468", 
		["Druide"] = "|cffff7c0a", 
		["Guerrier"] = "|cffc69b6d"
	},
	dungeonlist = {
		["Ahn'Qiraj"] = TRUE,
		["Blackfathom Deeps"] = TRUE,
		["Blackrock Depths"] = TRUE,
		["Blackrock Spire"] = TRUE,
		["Blackwing Lair"] = TRUE,
		["Caverns of Time"] = TRUE,
		["Dire Maul"] = TRUE,
		["Gnomeregan"] = TRUE,
		["Maraudon"] = TRUE,
		["Onyxia's Lair"] = TRUE,
		["Ragefire Chasm"] = TRUE,
		["Razorfen Downs"] = TRUE,
		["Razorfen Kraul"] = TRUE,
		["Scarlet Monastery"] = TRUE,
		["Scholomance"] = TRUE,
		["Shadowfang Keep"] = TRUE,
		["Stormwind Stockade"] = TRUE,
		["Stratholme"] = TRUE,
		["The Deadmines"] = TRUE,
		["The Molten Core"] = TRUE,
		["The Temple of Atal'Hakkar"] = TRUE,
		["The Wailing Caverns"] = TRUE,
		["Thunder Bluff"] = TRUE,
		["Uldaman"] = TRUE,
		["Zul'Farrak"] = TRUE,
		["Zul'Gurub"] = TRUE
	},
	battlegroundlist = {
		["Alterac Valley"] = TRUE,
		["Arathi Basin"] = TRUE,
		["Warsong Gulch"] = TRUE
	}
}

GuildFULocals.CMD_OPTIONS = {
	{
		option = GuildFULocals.ARGUMENT_SETLEADTEXT,
		desc = "Sets the leading text displayed in the bar.",
		method = "SetLeadText",
		input = TRUE,
		args = {
			{
				option = "<text>",
				desc = "This sets the leading text before the numbers in the bosspanel. Setting it to nil will clear the text."
			}
		}		
	},
	{
		option	= GuildFULocals.ARGUMENT_SETLEVELRANGE,
		desc	= "Sets the levelrange for the level filter in the menu.",
		method	= "SetLevelRange",
		input	= TRUE,
		args	= {
			{
				option	= "<#>",
				desc	= "A number between 0 and 10. Setting it to 0 will result in a filter for your level."
			}
		}		
	},
	{
		option	= GuildFULocals.ARGUMENT_SETREFRESH,
		desc	= "Sets the time in seconds between forced refreshes of the guild list.",
		method	= "SetRefreshRate",
		input	= TRUE,
		args	= {
			{
				option	= "<#>",
				desc	= "A number between 1 and 300. Setting it outside these numbers will result in setting it to the default value: " .. GuildFULocals.REFRESHINTERVAL
			}
		}		
	}
}

end
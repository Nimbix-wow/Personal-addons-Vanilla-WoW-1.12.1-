# ShaguStance
A Vanilla Addon that automatically switches to the required stance. E.g when trying to charge, while in berserk stance, it will automatically switch.

![battlestance](https://raw.githubusercontent.com/shagu/ShaguAddons/master/_img/ShaguStance/battlestance.jpg)

**Notice:**
*This Addon or a superior and maintained version of it, is already included in [pfUI](https://gitlab.com/shagu/pfUI). If using this in combination with pfUI you might get bad results or up to performance regressions.*

## Installation
1. Download **[Latest Version](https://gitlab.com/shagu/ShaguStance/-/archive/master/ShaguStance-master.zip)**
2. Unpack the Zip file
3. Rename the folder "ShaguStance-master" to "ShaguStance"
4. Copy "ShaguStance" into Wow-Directory\Interface\AddOns
5. Restart Wow
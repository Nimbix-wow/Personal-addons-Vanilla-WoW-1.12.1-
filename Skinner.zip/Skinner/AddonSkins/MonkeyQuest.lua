function Skinner:MonkeyQuest()
	self:applySkin(_G["MonkeyQuestFrame"])
end

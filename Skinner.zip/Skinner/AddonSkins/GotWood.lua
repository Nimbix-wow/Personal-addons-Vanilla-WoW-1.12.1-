
function Skinner:GotWood()

	self:applySkin(_G["GotWoodFrame"])

end

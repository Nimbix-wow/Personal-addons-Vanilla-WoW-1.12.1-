
function Skinner:Banknon()
	if not self.db.profile.ContainerFrames then return end
	
	self:applySkin(Banknon)
	
end

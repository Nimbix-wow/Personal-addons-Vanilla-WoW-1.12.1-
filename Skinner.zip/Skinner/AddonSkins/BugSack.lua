
function Skinner:BugSack()

	self:applySkin(_G["BugSackFrame"], nil, nil, nil, 200)

end


function Skinner:oCD()

	self:applySkin(_G["oCDFrame"])
	
end

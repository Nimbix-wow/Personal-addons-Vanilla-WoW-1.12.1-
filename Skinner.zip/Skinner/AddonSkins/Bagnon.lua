
function Skinner:Bagnon()
	if not self.db.profile.ContainerFrames then return end
	
	self:applySkin(Bagnon)
	
end

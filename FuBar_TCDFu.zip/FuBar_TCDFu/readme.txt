v1.4 
-removed the damn test msgs
v1.3
-fixed the cooldown problem with salt shaker
-changed snowball in same way cos i assume it has been changed too, plz post if that was wrong
V1.2
-added manual CD start options in menu until auto is fixed
-showing realmname / charname in tooltip now
v1.1
-fixed several bugs that remained from porting, sorry
v1.0
- first release
FuBar - PerformanceFu v2.0

Author: ckknight (ckknight@gmail.com)
$Date: 2006-08-09 22:43:29 -1000 (Wed, 09 Aug 2006) $

Keeps track of performance of memory, latency, and framerate.

TO INSTALL: Put the FuBar_PerformanceFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures

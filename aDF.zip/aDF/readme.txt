## aDF - a small frame that shows armor and few debuffs on your target.
## Author: Atreyyo @ Vanillagaming.org
######################################


Debuffs shown:

["Sunder Armor"] 
["Armor Shatter"]
["Faerie Fire"]
["Crystal Yield"]
["Nightfall"]
["Scorch"]
["Ignite"]
["Curse of Recklessness"] 
["Curse of the Elements"]
["Curse of Shadows"]
["Shadow Bolt"]
["Shadow Weaving"]
["Elemental Vulnerability"]


Feel free to make any suggestions to the addon.


--- Versions ---

added Vampiric Embrace

--- aDF 2.8
 
rewrote the update function, should improve performance
added "healermode" which let's you see the debuffs and armor of your friendly targets target

--- aDF 2.7

added ["Elemental Vulnerability"] ( MAge t3 6setbonus proc )

--- aDF 2.6

changed behaviour of the frame to only react when target is in combat rather than the player

--- aDF 2.5
added scaling function to main frame
added scaling slider and dropdown menu to choose channel for announcing armor/debuffs in options frame
added background to armor frame

--- aDF 2.0

added options menu frame
rewrote the core

--- aDF 1.0

First release
### TODO Features:
- "Ignore" option when right clicking players
- Set time individually
- Right click menu in ignore list frame
- Custom Filter should ignore non-latin characters

### Fix Bugs:
- WhisperUnignore doesn't work for trades, invites and duels

### Known problems:
- Can't remove chat bubbles
- "Duel cancelled" / "Trade cancelled" message is displayed

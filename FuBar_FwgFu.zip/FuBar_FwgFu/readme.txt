Description
------
FuBar - FwgFu (FelwoodGatherFu) is a FuBar plugin for FelwoodGather.
It display compact information of FelwoodGather timer on FuBar.
It can also trigger FelwoodGather functions from right click menu.

You can insert next spawn timer infomation to chat edit box by shift+click.

History
------
0.10
- support count down and minimap menu.
- Translate from TitanFelwoodGather 0.41


SaySapped for WoW Vanilla 1.12.1

Says "Sapped!" to alert those around you whenever a rogue saps you. Also works for many other CCs.

Type "/saysapped" for options in game.

Author: Coax - Anathema
Original idea: Bitbyte - Icecrown
    
Rename the addon folder "SaySapped" after extracting it!

If you want a simple version that just alerts for Sap, look at: https://github.com/Fiskehatt/SaySapped

NOTE: I should probably rewrite the whole addon :D

# RABuffs_ElysiumEdit
The Vanilla World of Warcraft addon (Client Version 1.12.1) edited to work on the Elysium Project servers.
Should work on other 1.12.1 servers as well, but has only been verified for the Anathema server of the Elysium Project.

How to install: click on "Clone or Download" -> "Download ZIP", unpack downloaded .zip file and rename folder contained inside to "RABuffs". Move folder "RABuffs" to your WoW directory\Interface\Addons folder. Done.

If the RABuffs frame is not visible to you after installation use the ingame command /rab show

Based on version 0.10.2 of RABuffs.
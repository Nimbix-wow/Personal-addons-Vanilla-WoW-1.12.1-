FuBar - MoneyFu v2

Current Maintainer: phyber (phyber@irc.freenode.net/#wowace)
Original Author: ckknight (ckknight@gmail.com)

Keeps track of current money and all your characters on one realm.

TO INSTALL: Put the FuBar_MoneyFu folder into
	\World of Warcraft\Interface\AddOns\

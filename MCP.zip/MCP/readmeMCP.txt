MCP - Master Control Program aka ACP - Addon Control Panel

MCP allows enabling/disabling addons in game without logging out.
Built in profiles allow to quickly switch addon sets.

Slash Commands:

/mcp 
- to open the panel (or choose new Addons option in game menu)

/mcp profileName 
- to quickly load profile be aware that non existing profile will return error and Ive no time for fancy idiot proof scripts 
so THINK before you type. It is case sensitive. It could bug if used in combat (tests didnt show it but there is possibility).

/mcp notSavedProfileName
- to return error so dont do it DOE !

Current Developer:
Dym aka Basara of Emerald Dream

Beta testing:
Lulleh of Emerald Dream

Original Author:
Marc aka Saien of Hyjal
WOWSaien@gmail.com
http://64.168.251.69/wow

Changelog: 
	
	22.07.2014
	2.3-BE release
		modifications by Basara of Emerald Dream
		- Reverted back to Vanilla (1.12.1)
		- Changed meta data and created readmeMCP.txt to provide better information about the addon
		- Added slash command /mcp profileName for quick profile swaps (can be easily put in macro etc.)

	2006.17.12
	3.0
		- Profiles can now be deleted
		- Updated for WoW / BC 2.0
	
	2006.09.09
	2.2-BD release
		- Made sure MCP doesn't turn itself off when checking disable all addons
	
	2006.09.06
	2.1-BD release
		- Added localization 
		- Added enable/disable all buttons
		- Added tooltip when you mouse over an addon to show the notes
	
	2006.09.02
	2.0-BD release
		modifications by Bluedragon of Frostwolf
		- Added slash command /mcp to open the window
		- Added profiles for quickly changing which addons are enabled/disabled
	
	2006.01.02
	1.9 release
		- In game changes to the addon list are limited to changing the currently 
		logged in character only. You cannot change Addons for other characters. 
		This is a Blizzard restriction.

	2005.10.10
	1.8 release
FuBar - VolumeFu v2.0.$Revision: 11030 $

Author: Aileen
$Date: 2006-09-16 11:31:40 -0400 (Sat, 16 Sep 2006) $

Controls the game volume settings.

INSTALL: Put the FuBar_VolumeFu folder into the AddOns folder
     e.g. c:\Games\World of Warcraft\Interface\AddOns\

BUGS: http://www.wowinterface.com/portal.php?id=86&a=listbugs

REQUESTS:  http://www.wowinterface.com/portal.php?id=86&a=listfeatures 

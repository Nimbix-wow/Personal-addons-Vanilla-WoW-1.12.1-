avbars - a World of Warcraft (1.12.1) AddOn (modification)
====================================

Installation:

Put "avbars" folder into ".../World of Warcraft/Interface/AddOns/".
Create AddOns folder if necessary

After Installation directory tree should look like the following

<pre>
World of Warcraft
`- Interface
   `- AddOns
      `- avbars
         |-- README.md
         |-- avbars.lua
         |-- avbars.toc
         `-- avbars.xml

</pre>

Features:
- (AV) Snowfall Graveyard captureis now announced to battleground chat,
- Timers will be picked up from chat if missing.

Known Issues:
- None.

Notes:
- I am **not the original author** of this AddOn.